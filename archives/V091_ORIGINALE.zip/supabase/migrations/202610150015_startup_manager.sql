-- EURACONNECT V0.9.1 : portefeuille startup manager / supervision securisee.
-- A executer apres 202610150014_admin_premium.sql. Migration additive.
begin;
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('admin','incube','prestataire','startup_manager'));

create table if not exists public.ec_manager_portefeuille (
 manager_id uuid not null references public.profiles(id) on delete restrict,
 entreprise_id uuid not null references public.entreprises_ec(id) on delete restrict,
 attribue_par uuid not null references public.profiles(id),
 created_at timestamptz not null default now(),
 primary key(manager_id,entreprise_id)
);
create index if not exists ec_manager_portefeuille_entreprise_idx on public.ec_manager_portefeuille(entreprise_id);
alter table public.ec_manager_portefeuille enable row level security;
revoke all on public.ec_manager_portefeuille from public,anon,authenticated;
-- Lecture/edition uniquement au travers de fonctions SQL verifiant auth.uid() et organisation.

create or replace function public.ec91_manager_autorise()
returns boolean language sql stable security definer set search_path='' as $f$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='startup_manager' and p.statut='actif');
$f$;

create or replace function public.ec91_admin_managers()
returns jsonb language plpgsql stable security definer set search_path='' as $f$
declare v jsonb;
begin
 if not public.est_admin() then raise exception 'Acces administrateur requis'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',p.id,'nom',coalesce(nullif(p.nom,''),u.email),'email',u.email) order by p.nom), '[]'::jsonb)
 into v from public.profiles p join auth.users u on u.id=p.id where p.role='startup_manager' and p.statut='actif' and p.organisation_id=public.mon_organisation();
 return v;
end $f$;

create or replace function public.ec91_admin_portefeuilles()
returns jsonb language plpgsql stable security definer set search_path='' as $f$
declare v jsonb;
begin
 if not public.est_admin() then raise exception 'Acces administrateur requis'; end if;
 select jsonb_build_object(
  'startups',coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'nom',e.nom,'statut',e.statut) order by e.nom)
   from public.entreprises_ec e where e.type='startup' and e.organisation_id=public.mon_organisation()),'[]'::jsonb),
  'assignations',coalesce((select jsonb_agg(jsonb_build_object('manager_id',a.manager_id,'entreprise_id',a.entreprise_id))
   from public.ec_manager_portefeuille a join public.entreprises_ec e on e.id=a.entreprise_id
   where e.organisation_id=public.mon_organisation()),'[]'::jsonb)) into v;
 return v;
end $f$;

create or replace function public.ec91_admin_modifier_manager(p_email text,p_activer boolean)
returns void language plpgsql security definer set search_path='' as $f$
declare v_id uuid;v_role text;
begin
 if not public.est_admin() then raise exception 'Acces administrateur requis';end if;
 select p.id,p.role into v_id,v_role from auth.users u join public.profiles p on p.id=u.id
 where lower(u.email)=lower(trim(p_email)) and p.organisation_id=public.mon_organisation();
 if v_id is null then raise exception 'Compte existant introuvable';end if;
 if v_role='admin' then raise exception 'Impossible de modifier un administrateur';end if;
 if p_activer then
  if v_role='incube' and exists(select 1 from public.entreprise_membres_ec where profile_id=v_id and actif) then
   raise exception 'Retirer d abord les affiliations startup actives avant conversion';end if;
  if v_role='prestataire' and exists(select 1 from public.entreprise_membres_ec where profile_id=v_id and actif) then
   raise exception 'Retirer d abord les affiliations prestataire actives avant conversion';end if;
  update public.profiles set role='startup_manager',updated_at=now() where id=v_id;
 else
  if v_role<>'startup_manager' then raise exception 'Ce compte n est pas Startup Manager';end if;
  delete from public.ec_manager_portefeuille where manager_id=v_id;
  update public.profiles set role='incube',updated_at=now() where id=v_id;
 end if;
 insert into public.audit_log(acteur_id,action,cible_type,cible_id,detail)
 values(auth.uid(),'ec91_role_manager','profiles',v_id,jsonb_build_object('active',p_activer));
end $f$;

create or replace function public.ec91_admin_assigner(p_manager uuid,p_entreprise uuid,p_activer boolean)
returns void language plpgsql security definer set search_path='' as $f$
begin
 if not public.est_admin() then raise exception 'Acces administrateur requis';end if;
 if not exists (select 1 from public.profiles p where p.id=p_manager and p.role='startup_manager' and p.statut='actif' and p.organisation_id=public.mon_organisation())
 then raise exception 'Manager non autorise';end if;
 if not exists(select 1 from public.entreprises_ec e where e.id=p_entreprise and e.type='startup' and e.organisation_id=public.mon_organisation())
 then raise exception 'Entreprise startup invalide';end if;
 if p_activer then
  insert into public.ec_manager_portefeuille(manager_id,entreprise_id,attribue_par) values(p_manager,p_entreprise,auth.uid()) on conflict do nothing;
 else
  delete from public.ec_manager_portefeuille where manager_id=p_manager and entreprise_id=p_entreprise;
 end if;
 insert into public.audit_log(acteur_id,action,cible_type,cible_id,detail)
 values(auth.uid(),'ec91_affectation_manager','entreprises_ec',p_entreprise,jsonb_build_object('manager_id',p_manager,'active',p_activer));
end $f$;

-- Tableau manager : uniquement donnees des startups attribuees, jamais de message prive ni de contact hors portefeuille.
-- La fonction ne divulgue pas les donnees via les policies directes RLS.
create or replace function public.ec91_mon_portefeuille()
returns jsonb language plpgsql stable security definer set search_path='' as $f$
declare v jsonb;
begin
 if not public.ec91_manager_autorise() then raise exception 'Compte Startup Manager actif requis';end if;
 with portefeuille as (
  select e.id,e.nom,e.statut from public.ec_manager_portefeuille a
  join public.entreprises_ec e on e.id=a.entreprise_id
  where a.manager_id=auth.uid() and e.type='startup' and e.organisation_id=public.mon_organisation()
 ), besoins as (
  select j.id,j.entreprise_id,j.titre,j.statut_suivi,j.created_at
  from public.projets j join portefeuille p on p.id=j.entreprise_id
 ), contacts as (
  select b.entreprise_id,count(distinct c.prestataire_id)::int as prestataires,
   count(c.id)::int as candidatures
  from besoins b left join public.candidatures c on c.projet_id=b.id
  group by b.entreprise_id
 ), rdvs as (
  select r.id,r.startup_entreprise_id,d.debut,r.statut,p.nom_public as prestataire,
   r.objet_public as objet
  from public.reservations_rdv r
  join public.disponibilites_rdv d on d.id=r.disponibilite_id
  join public.prestataires p on p.id=d.prestataire_id
  join portefeuille e on e.id=r.startup_entreprise_id
 ), synthese as (
  select p.id,p.nom,p.statut,
   (select count(*)::int from besoins b where b.entreprise_id=p.id) as nb_besoins,
   (select count(*)::int from besoins b where b.entreprise_id=p.id and b.statut_suivi not in ('termine','sans_suite')) as besoins_actifs,
   coalesce(c.candidatures,0) as candidatures,coalesce(c.prestataires,0) as prestataires,
   (select count(*)::int from rdvs r where r.startup_entreprise_id=p.id) as nb_rdv,
   (select count(*)::int from rdvs r where r.startup_entreprise_id=p.id and r.debut>=now() and r.statut<>'annule') as rdv_a_venir
  from portefeuille p left join contacts c on c.entreprise_id=p.id
 )
 select jsonb_build_object(
   'startups',coalesce((select jsonb_agg(to_jsonb(s) order by s.nom) from synthese s),'[]'::jsonb),
   'besoins',coalesce((select jsonb_agg(jsonb_build_object('id',b.id,'entreprise_id',b.entreprise_id,'titre',b.titre,'statut',b.statut_suivi,'date',b.created_at,'reponses',(select count(*)::int from public.candidatures c where c.projet_id=b.id)) order by b.created_at desc) from besoins b),'[]'::jsonb),
   'rdv',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'entreprise_id',r.startup_entreprise_id,'debut',r.debut,'statut',r.statut,'prestataire',r.prestataire,'objet',r.objet) order by r.debut desc) from rdvs r),'[]'::jsonb),
   'contacts',coalesce((select jsonb_agg(jsonb_build_object('entreprise_id',b.entreprise_id,'prestataire',p.nom_public,'besoin',b.titre,'date',c.created_at,'statut',c.statut) order by c.created_at desc)
      from besoins b join public.candidatures c on c.projet_id=b.id join public.prestataires p on p.id=c.prestataire_id),'[]'::jsonb)
 ) into v;
 return coalesce(v,'{}'::jsonb);
end $f$;

revoke all on function public.ec91_manager_autorise(),public.ec91_admin_managers(),public.ec91_admin_portefeuilles(),public.ec91_admin_modifier_manager(text,boolean),public.ec91_admin_assigner(uuid,uuid,boolean),public.ec91_mon_portefeuille() from public,anon;
grant execute on function public.ec91_manager_autorise(),public.ec91_admin_managers(),public.ec91_admin_portefeuilles(),public.ec91_admin_modifier_manager(text,boolean),public.ec91_admin_assigner(uuid,uuid,boolean),public.ec91_mon_portefeuille() to authenticated;
commit;
