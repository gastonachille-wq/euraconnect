 'use client';
import {useEffect,useState} from 'react';
import {db} from '@/lib/supabase';
import {BriefcaseBusiness,CalendarDays,Building2,RefreshCw,Search,UsersRound} from 'lucide-react';
type Startup={id:string;nom:string;statut:string;nb_besoins:number;besoins_actifs:number;candidatures:number;prestataires:number;nb_rdv:number;rdv_a_venir:number};
type Besoin={id:string;entreprise_id:string;titre:string;statut:string;date:string;reponses:number};
type Rdv={id:string;entreprise_id:string;debut:string;statut:string;prestataire:string;objet:string};
type Contact={entreprise_id:string;prestataire:string;besoin:string;date:string;statut:string};
type Rapport={startups:Startup[];besoins:Besoin[];rdv:Rdv[];contacts:Contact[]};
const empty:Rapport={startups:[],besoins:[],rdv:[],contacts:[]};
const errorText=(e:unknown)=>e&&typeof e==='object'&&'message'in e?String((e as {message:unknown}).message):String(e);
export default function StartupManagerDashboard(){
 const [data,setData]=useState<Rapport>(empty),[loading,setLoading]=useState(true),[error,setError]=useState('');
 const [filter,setFilter]=useState(''),[selected,setSelected]=useState('');
 async function load(){setLoading(true);setError('');try{const r=await db().rpc('ec91_mon_portefeuille');if(r.error)throw r.error;const v=(r.data||{}) as Partial<Rapport>;setData({startups:v.startups||[],besoins:v.besoins||[],rdv:v.rdv||[],contacts:v.contacts||[]});}catch(e){setError(errorText(e));}finally{setLoading(false);}}
 useEffect(()=>{void load();},[]);
 const visible=data.startups.filter(x=>(!selected||selected===x.id)&&x.nom.toLocaleLowerCase('fr').includes(filter.toLocaleLowerCase('fr')));
 const scoped=new Set(visible.map(x=>x.id));
 const needs=data.besoins.filter(x=>scoped.has(x.entreprise_id));
 const meetings=data.rdv.filter(x=>scoped.has(x.entreprise_id));
 const contacts=data.contacts.filter(x=>scoped.has(x.entreprise_id));
 const totals={startups:visible.length,besoins:visible.reduce((s,x)=>s+x.besoins_actifs,0),reponses:visible.reduce((s,x)=>s+x.candidatures,0),rdv:visible.reduce((s,x)=>s+x.rdv_a_venir,0)};
 const name=(id:string)=>data.startups.find(x=>x.id===id)?.nom||'Startup';
 return <section className="ec08-page ec91-manager"><div className="ec08-page-title"><div><span className="section-eyebrow">Accompagnement des incubés</span><h1>Mon portefeuille startups</h1><p className="sub">Besoins, réponses reçues, rendez-vous et contacts prestataires — uniquement pour les startups qui vous sont attribuées.</p></div><button className="btn ghost" type="button" onClick={()=>void load()} disabled={loading}><RefreshCw size={16}/> Actualiser</button></div>
 {error&&<div className="alert" role="alert">{error}</div>}
 <div className="panel ec91-filters"><label>Rechercher une startup <input value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Nom de l'entreprise…"/></label><label>Portefeuille <select value={selected} onChange={e=>setSelected(e.target.value)}><option value="">Toutes mes startups</option>{data.startups.map(s=><option value={s.id} key={s.id}>{s.nom}</option>)}</select></label></div>
 <div className="ec91-kpis">{([{label:'Startups suivies',value:totals.startups,icon:Building2},{label:'Besoins actifs',value:totals.besoins,icon:BriefcaseBusiness},{label:'Réponses reçues',value:totals.reponses,icon:UsersRound},{label:'RDV à venir',value:totals.rdv,icon:CalendarDays}] as const).map(k=><div className="panel ec91-kpi" key={k.label}><k.icon size={20}/><strong>{k.value}</strong><span>{k.label}</span></div>)}</div>
 <h2>Startups accompagnées</h2><div className="ec91-startups">{visible.map(s=><article className="panel ec91-startup" key={s.id}><h3>{s.nom}</h3><div className="ec91-mini"><span>{s.besoins_actifs} besoins actifs</span><span>{s.candidatures} réponses</span><span>{s.prestataires} prestataires en contact</span><span>{s.rdv_a_venir} RDV à venir</span></div><button className="btn ghost small" onClick={()=>setSelected(s.id)}>Analyser cette startup</button></article>)}{!loading&&!visible.length&&<div className="empty">Aucune startup attribuée pour cette sélection. Contactez l’administrateur pour gérer votre portefeuille.</div>}</div>
 <div className="ec91-duo"><section className="panel"><h2>Demandes et opportunités</h2><p className="sub">Suivi des besoins publiés et du nombre de réponses reçues.</p><div className="ec91-scroll">{needs.map(b=><div className="ec91-line" key={b.id}><div><b>{b.titre}</b><small>{name(b.entreprise_id)} · {new Date(b.date).toLocaleDateString('fr-FR')}</small></div><div><span className="pill">{b.statut.replaceAll('_',' ')}</span><small>{b.reponses} réponse(s)</small></div></div>)}{!needs.length&&<p>Aucun besoin pour cette sélection.</p>}</div></section>
 <section className="panel"><h2>Rendez-vous et interlocuteurs</h2><p className="sub">Qui rencontre qui, quand et pourquoi ?</p><div className="ec91-scroll">{meetings.map(r=><div className="ec91-line" key={r.id}><div><b>{r.prestataire}</b><small>{name(r.entreprise_id)} · {new Date(r.debut).toLocaleString('fr-FR',{dateStyle:'medium',timeStyle:'short'})}</small><small>Objet : {r.objet||'Non précisé'}</small></div><span className="pill">{r.statut}</span></div>)}{!meetings.length&&<p>Aucun rendez-vous pour cette sélection.</p>}</div></section></div>
 <section className="panel"><h2>Prestataires entrés en contact</h2><p className="sub">Entreprises ayant répondu à un besoin du portefeuille, avec le besoin concerné et la date.</p><div className="ec91-scroll">{contacts.map((c,i)=><div className="ec91-line" key={`${c.entreprise_id}-${c.prestataire}-${i}`}><div><b>{c.prestataire}</b><small>{name(c.entreprise_id)} · {c.besoin}</small><small>{new Date(c.date).toLocaleDateString('fr-FR')}</small></div><span className="pill">{c.statut.replaceAll('_',' ')}</span></div>)}{!contacts.length&&<p>Aucune réponse prestataire enregistrée pour cette sélection.</p>}</div></section>
 <p className="sub">Les informations présentées sont consultables en lecture seule. Les contenus des échanges privés ne sont pas accessibles depuis cet espace.</p>
 </section>;
}
