# EURACONNECT V0.9.1 — Startup Manager

## Objectif
Le rôle `startup_manager` est distinct de `incube`, `prestataire` et `admin`. Le manager ne voit que les startups **explicitement attribuées par un administrateur**. Il peut superviser le nombre de besoins, les candidatures, le nombre de prestataires sollicités, les rendez-vous, leurs objets et leur date. Il ne reçoit aucun droit de modification des besoins, contacts ou conversations privées.

## Installation
1. Sauvegarder la base de recette Supabase.
2. Exécuter **uniquement** `supabase/migrations/202610150015_startup_manager.sql` après la migration V0.9.0.
3. Déployer le projet Next.js complet sur une branche de recette Netlify.
4. Créer au préalable un compte utilisateur dans Supabase Auth.
5. Dans l'espace Administration, section Startup Managers, activer le rôle par email et attribuer des startups existantes.
6. Se connecter au compte manager. Il arrive sur `Mon portefeuille startups`. Vérifier les indicateurs et le filtre par entreprise.

## Recette et sécurité
- Le manager n'a aucun accès tant qu'aucune startup n'est attribuée.
- Le manager A n'accède pas aux données d'une startup attribuée uniquement au manager B.
- Les rendez-vous affichent date, prestataire et objet, mais **pas** les messages privés ni les coordonnées personnelles.
- Les affectations et changements de rôle sont réservés à `est_admin()` et auditables dans `audit_log`.
- Un ancien incubé possédant encore des affiliations actives ne peut pas être converti directement en manager, pour éviter des droits contradictoires.
- Un manager ne peut ni publier de besoin ni répondre comme prestataire.
- Les besoins historiques sans `entreprise_id` ne sont pas automatiquement repris : rattachement à traiter séparément si nécessaire.
- Le nombre de prestataires en contact compte les prestataires avec au moins une candidature, pas les contacts hors plateforme.
- Les rendez-vous reflètent uniquement les rendez-vous enregistrés dans EURACONNECT.
- Les indicateurs sont recalculés lors du chargement et de l'actualisation ; aucune notification proactive dans cette version.

## Validations
Ne pas installer sur production avant passage de `npm run typecheck`, `npm run build` et des essais avec deux managers de portefeuilles distincts.
